/*	
	Title: SQL DML Queries
	Date: 1-4-2018
	Database: DreamHome 
	Source: Chapter: 5, Page: 112, SQL: Data Manipulation
*/

use dreamhome
-- List full details of all staff.
-- 'SET NOCOUNT OFF is used to remove the row count number in the message part'
        SET NOCOUNT OFF;


		SELECT position, fName, lName,  gender, DOB, salary, branchNo, staffNo
		FROM Staff

-- Can use * as an abbreviation for �all columns�:

		SELECT *
		FROM Staff;
		
-- Produce a list of salaries for all staff, showing only  staff number, first and last names, and salary.

		SELECT salary, staffNo, fName, lName 
		FROM Staff;

-- List the staff numbers of all staff who oversees a property.

		SELECT staffno
		FROM PropertyForRent
		
-- Use DISTINCT to eliminate duplicates

		SELECT DISTINCT staffno
		FROM PropertyForRent

-- produce a list of monthly salaries for all staff, showing staff number, first and last names, and  salary details.

	
	SELECT staffNo, fName, lName,salary, salary/12 AS [Mon Sal] FROM Staff;

-- To name column, use AS clause:

   	SELECT staffNo, fName, lName,salary,  salary/12 as [monthly salary]
	FROM Staff;
	
-- List all staff with a salary greater than 10,000.

	SELECT staffNo, fName
	FROM Staff
	WHERE salary > 10000;
	
-- List addresses of all branch offices in London or Glasgow.

		SELECT *
		FROM Branch
		WHERE city = 'London' OR  'Glasgow';

-- List all staff with a salary between 20,000 and 30,000.

	SELECT staffNo, fName, lName, position, salary
	FROM Staff
	WHERE salary  NOT BETWEEN 20000 AND 30000;


-- Also a negated version NOT BETWEEN. 


	SELECT staffNo, fName, lName, position, salary
	FROM Staff
	WHERE salary >= 20000 AND salary <= 30000;

-- List all managers and supervisors.

	SELECT staffNo, fName, lName, position
	FROM Staff
	WHERE position  IN ('Manager', 'Supervisor');
	
-- alternative

    SELECT staffNo, fName, lName, position
	FROM Staff
    WHERE position='Manager' OR position='Supervisor';

-- Find all staff first names that contain the letter (a)

select * from staff;

	SELECT *
	FROM staff
	WHERE fname LIKE '[_]___';

-- List details of all property for rent which has not been overseen by any staff

	SELECT * 
	FROM PropertyForRent
	WHERE staffno IS not  NULL;
	
-- List salaries for all staff, arranged in descending order of salary.

	SELECT staffNo, fName, lName, salary
	FROM Staff
	ORDER BY salary desc;
	
-- Produce abbreviated list of properties in order of property type.

	SELECT propertyNo, type, rooms, rent
	FROM PropertyForRent
	ORDER BY type;

-- Multiple Column Ordering

	SELECT propertyNo, type, rooms, rent
	FROM PropertyForRent
	ORDER BY type, rent desc;

-- How many properties cost more than �350 per month to rent?

	SELECT COUNT(*) AS count1
	FROM PropertyForRent
	--WHERE rent > 350;
	
-- Use DISTINCT

	SELECT count (DISTINCT staffno)
	FROM PropertyForRent

-- Find number of Managers and sum of their salaries.

	SELECT COUNT(staffNo) AS count, SUM(salary) AS sum
	FROM Staff
	WHERE position = 'Manager';
	
-- Find minimum, maximum, and average staff salary.

	SELECT MIN(salary) AS min, MAX(salary) AS max, AVG(salary) AS avg
	FROM Staff;

-- Find the total number of staffs in each branch and their total salaries.

	SELECT branchNo, COUNT(staffNo) AS count, SUM(salary) AS sum
	FROM Staff
	GROUP BY branchNo
	--ORDER BY branchNo;
	
-- For each branch with more than 1 member of staff, find number of staff 
-- in each branch and sum of their salaries.

	SELECT branchNo, COUNT(staffNo) AS count, SUM(salary) AS sum
	FROM Staff
	GROUP BY branchNo
	HAVING COUNT(staffNo) > 2
	ORDER BY branchNo;

-- List staff who work in branch at '163 Main St'.

	SELECT staffNo, fName, lName, position
	FROM Staff
	WHERE branchNo =
					(SELECT branchNo
					 FROM Branch
					 WHERE street = '163 Main St');
					 
-- List all staff whose salary is greater than the average salary, and show by how much.

	SELECT staffNo, fName, lName, position, salary ,salary - (SELECT AVG(salary) FROM Staff) As SalDiff
	FROM Staff
	WHERE salary > (select AVG(salary)FROM Staff);

-- List properties handled by staff at �163 Main St�.

	SELECT propertyNo, street, city, postcode, type, rooms, rent
	FROM PropertyForRent
	WHERE staffNo IN
					(SELECT staffNo
					 FROM Staff
					 WHERE branchNo =
									(SELECT branchNo
									 FROM Branch
									 WHERE street = '163 Main St'));

-- List names of all staffs and branches details.

	SELECT fname, lname, Branch.*
	FROM Staff, Branch	
	WHERE Staff.branchno = Branch.branchno
	
-- using alias for tables names

	SELECT S.fname, S.lname,B.*
	FROM Staff S, Branch B	
	WHERE S.branchno = B.branchno
	
-- Three tables join	
-- For each branch, list staff who manage properties, including city in which branch 
-- is located and properties they manage.

	SELECT b.branchNo, b.city, s.staffNo, s.fName, s.lName, p.propertyNo
	FROM Branch b, Staff s, PropertyForRent p
	WHERE b.branchNo = s.branchNo AND s.staffNo = p.staffNo
	ORDER BY b.branchNo, s.staffNo, propertyNo;

-- Find number of properties handled by each staff member.
	
	SELECT s.staffNo , COUNT(*) AS count
	FROM Staff s, PropertyForRent p
	WHERE s.staffNo = p.staffNo
	GROUP BY s.staffNo
	ORDER BY s.staffNo;
	
-- Find all staff who work in a London branch. (Exists)

  SELECT staffNo, fName, lName, position
  FROM Staff s
  WHERE EXISTS
		(SELECT *
		 FROM Branch b
		 WHERE s.branchNo = b.branchNo AND 
	  		     city = 'London');



-- Insert a new row into Staff table supplying data for all columns.

INSERT INTO Staff
VALUES ('SG16', 'Alan', 'Brown', 'Assistant', 'M', '1957-05-25', 8300, 'B003');

-- Insert a new row into Staff table supplying data for all mandatory columns.

	INSERT INTO Staff (staffNo, fName, lName, position, salary, branchNo)
	VALUES ('SG44', 'Anne', 'Jones', 'Assistant', '8100', 'B003');
	
-- Same with NULL values

	INSERT INTO Staff
	VALUES ('SG45', 'Anne', 'Jones', 'Assistant', NULL,
                    NULL, 8100, 'B003');
                    
-- Update staff SA9 Salary by %3

	UPDATE Staff
	SET salary = salary*1.03
	WHERE Staffno = 'SA9'
	
-- Promote Anne Jones (staffNo = 'SG45') to Manager and change her salary to �18,000.

		UPDATE Staff
		SET position = 'Manager', salary = 18000
		WHERE staffNo = 'SG45';
		
-- Delete staff who has the numbers SG45, SG44 and SG16.

		DELETE FROM staff
		WHERE staffno = 'SG45' and staffno = 'SG44' OR staffno = 'SG16';





	
















		


